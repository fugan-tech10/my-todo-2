import React from 'react'

export const Completed = ({completedList, setCompletedList}) => {
    const onClickDelete = (id) => {
        console.log(id);
        setCompletedList(completedList.filter(todo => todo.id!== id));
    }

  return (
    <>
    <h2>Completed!</h2>
    <table>
        <tbody>
            {completedList.map((todo, index) => (
                <tr>
                    <td>{index}</td>
                    <td>{todo.text}</td>
                    <td><button onClick={() => onClickDelete(todo.id)}>削除</button></td>
                </tr>
            ))}
        </tbody>
    </table>
    </>
  )
}
