import React, { useContext } from "react";
import { todoContext } from "../App";

export const TodoList = ({
  completedList,
  setCompletedList,
}) => {
    const [taskList, setTaskList] = useContext(todoContext);
  const onClickImmidiate = (id, todo) => {
    setTaskList(
      taskList.map((todo) => {
        if (id === todo.id) {
          return {
            ...todo,
            immidiate: true,
          };
        }
      })
    );
    console.log(taskList);
  };
  const onClickLater = (id) => {
    setTaskList(
      taskList.map((todo) => {
        if (id === todo.id) {
          return {
            ...todo,
            immidiate: false,
          };
        }
      })
    );
    console.log(taskList)
  };
  const onClickComplete = (todo) => {
    setCompletedList([...completedList, { todo }]);
    console.log(completedList);
  };
  const onClickDelete = (id) => {
    console.log(id);
    setTaskList(taskList.filter((todo) => todo.id !== id));
  };

  return (
    <>
      <h2>current task</h2>
      <table>
        <thead>
          <tr>
            <td>No.</td>
            <td>やること</td>
          </tr>
        </thead>
        <tbody>
         {taskList.map((todo, index) => (
            <tr
              key={todo.text}
            >
              <td>{index}</td>
              <td>{todo.text}</td>
              <td>
                <button className={`${todo.immidiate ? "immidiate" : ""}`} onClick={() => onClickImmidiate(todo.id, todo)}>すぐ</button>
              </td>
              <td>
                <button className={`${todo.immidiate ? "" : "later"}`} onClick={() => onClickLater(todo.id)}>あとで</button>
              </td>
              <td>
                <button onClick={() => onClickComplete(todo)}>完了</button>
              </td>
              <td>
                <button onClick={() => onClickDelete(todo.id)}>削除</button>
              </td>
            </tr>
          ))} 
        </tbody>
      </table>
      {/* <Completed completedList={completedList} setCompletedList={setCompletedList}/> */}
    </>
  );
};
