import React, {useState, useContext} from 'react';
import { todoContext } from '../App';

export const Inputform = () => {
    const [taskList, setTaskList] = useContext(todoContext);
    const [inputText, setInputText] = useState("");
    

    const handleChange = (e) => {
        setInputText(e.target.value);
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        setTaskList([
            ...taskList,
            {
            id: inputText,
            text: inputText,
            immidiate: true
            }
        ]);   
        console.log(taskList);
        setInputText("");
 
    }

  return (
    <>
    <form onSubmit={handleSubmit}>
        <input type="text" onChange={handleChange} value={inputText} />
        <button>ADD</button>
    </form>
    </>
  )
}
