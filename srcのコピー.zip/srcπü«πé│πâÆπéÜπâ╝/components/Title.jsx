import React from "react";

export const Title = () => {
  return (
    <div>
        <header>
            <h1>Todo List</h1>
        </header>
    </div>
  )
}
